import 'package:flutter/material.dart';

class ResultPage extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    final Map<String, Object> resultData =
        ModalRoute.of(context)!.settings.arguments as Map<String, Object>;
    final int score = resultData["score"] as int;
    final List<Map<String, Object>> answers =
        resultData["answers"] as List<Map<String, Object>>;

    return Scaffold(
      appBar: AppBar(
        title: Text('Sonuçlar'),
      ),
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: <Widget>[
            Text(
              'Skorunuz: $score',
              style: TextStyle(fontSize: 30),
            ),
            SizedBox(height: 20),
            ElevatedButton(
              onPressed: () {
                Navigator.pushReplacementNamed(context, '/home');
              },
              child: Text('Ana Menü'),
            ),
            SizedBox(height: 20),
            Text(
              'Doğru ve Yanlış Cevaplar',
              style: TextStyle(fontSize: 20),
            ),
            Expanded(
              child: ListView.builder(
                itemCount: answers.length,
                itemBuilder: (context, index) {
                  return ListTile(
                    title: Text(answers[index]['question'] as String),
                    subtitle: Text(
                      'Verilen Cevap: ${answers[index]['givenAnswer']} - Doğru Cevap: ${answers[index]['correctAnswer']}',
                      style: TextStyle(
                          color: answers[index]['isCorrect'] as bool
                              ? Colors.green
                              : Colors.red),
                    ),
                  );
                },
              ),
            ),
          ],
        ),
      ),
    );
  }
}
