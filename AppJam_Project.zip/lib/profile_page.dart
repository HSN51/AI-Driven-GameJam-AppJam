import 'package:flutter/material.dart';

class ProfilePage extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    // Skor ve yanlış cevap sayısı gibi bilgileri buradan alın
    final int score = 120; // Örnek veri
    final int wrongAnswers = 5; // Örnek veri

    return Scaffold(
      appBar: AppBar(
        title: Text('Profil'),
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          children: [
            SizedBox(height: 20),
            CircleAvatar(
              radius: 50,
              backgroundImage:
                  AssetImage('assets/anon_profile.png'), // Anonim profil resmi
            ),
            SizedBox(height: 20),
            Text(
              'Hasan', // Kullanıcı adı
              style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold),
            ),
            SizedBox(height: 20),
            Text(
              'Skor: $score',
              style: TextStyle(fontSize: 20),
            ),
            Text(
              'Yanlış Cevaplar: $wrongAnswers',
              style: TextStyle(fontSize: 20),
            ),
            SizedBox(height: 20),
            ElevatedButton(
              onPressed: () {
                Navigator.pushReplacementNamed(context, '/home');
              },
              child: Text('Ana Menüye Dön'),
            ),
          ],
        ),
      ),
    );
  }
}
