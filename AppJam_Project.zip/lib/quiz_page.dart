import 'package:flutter/material.dart';

class QuizPage extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    final String topic = ModalRoute.of(context)!.settings.arguments as String;

    final List<Map<String, Object>> questions = getQuestionsForTopic(topic);

    return Scaffold(
      appBar: AppBar(
        title: Text('$topic Soruları'),
      ),
      body: Quiz(questions: questions),
    );
  }

  List<Map<String, Object>> getQuestionsForTopic(String topic) {
    if (topic == "Yazılım") {
      return [
        {
          "question":
              "Hangi dil, web geliştirme için yaygın olarak kullanılır?",
          "answers": ["Python", "HTML", "C++", "Java"],
          "correctAnswer": "HTML"
        },
        {
          "question": "Python'da kullanılan veri yapılarından biri nedir?",
          "answers": ["Array", "Tuple", "LinkedList", "Binary Tree"],
          "correctAnswer": "Tuple"
        },
        {
          "question": "Git nedir?",
          "answers": [
            "Bir programlama dili",
            "Bir versiyon kontrol sistemi",
            "Bir veritabanı",
            "Bir web tarayıcısı"
          ],
          "correctAnswer": "Bir versiyon kontrol sistemi"
        }
      ];
    }
    // Diğer kategoriler için sorular ekleyin...
    return [
      {
        "question": "Einstein hangi teoriyi geliştirmiştir?",
        "answers": [
          "Görelilik Teorisi",
          "Kuantum Teorisi",
          "Kaos Teorisi",
          "Çekim Teorisi"
        ],
        "correctAnswer": "Görelilik Teorisi"
      },
      {
        "question": "Dünya'nın en büyük okyanusu hangisidir?",
        "answers": [
          "Atlas Okyanusu",
          "Hint Okyanusu",
          "Büyük Okyanus",
          "Arktik Okyanusu"
        ],
        "correctAnswer": "Büyük Okyanus"
      },
      {
        "question": "Leonardo da Vinci hangi ünlü eseri yaratmıştır?",
        "answers": [
          "Mona Lisa",
          "Yıldızlı Gece",
          "Düşünen Adam",
          "Son Akşam Yemeği"
        ],
        "correctAnswer": "Mona Lisa"
      }
    ];
  }
}

class Quiz extends StatefulWidget {
  final List<Map<String, Object>> questions;

  Quiz({required this.questions});

  @override
  _QuizState createState() => _QuizState();
}

class _QuizState extends State<Quiz> {
  int _questionIndex = 0;
  int _score = 0;
  List<Map<String, Object>> _answers = [];

  void _answerQuestion(String answer) {
    bool isCorrect =
        widget.questions[_questionIndex]['correctAnswer'] == answer;
    if (isCorrect) {
      setState(() {
        _score++;
      });
    }
    _answers.add({
      "question": widget.questions[_questionIndex]['question'] as String,
      "givenAnswer": answer,
      "correctAnswer":
          widget.questions[_questionIndex]['correctAnswer'] as String,
      "isCorrect": isCorrect
    });

    setState(() {
      _questionIndex++;
    });

    if (_questionIndex == widget.questions.length) {
      Navigator.pushReplacementNamed(context, '/result',
          arguments: {"score": _score, "answers": _answers});
    }
  }

  @override
  Widget build(BuildContext context) {
    return _questionIndex < widget.questions.length
        ? Column(
            children: [
              Padding(
                padding: const EdgeInsets.all(16.0),
                child: Text(
                  widget.questions[_questionIndex]['question'] as String,
                  style: TextStyle(fontSize: 20.0),
                ),
              ),
              ...(widget.questions[_questionIndex]['answers'] as List<String>)
                  .map((answer) {
                return ElevatedButton(
                  child: Text(answer),
                  onPressed: () => _answerQuestion(answer),
                );
              }).toList(),
            ],
          )
        : Center(
            child: Text('Skorunuz: $_score/${widget.questions.length}'),
          );
  }
}
