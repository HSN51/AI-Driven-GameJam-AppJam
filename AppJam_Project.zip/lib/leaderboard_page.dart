import 'package:flutter/material.dart';

class LeaderboardPage extends StatelessWidget {
  final List<Map<String, Object>> leaderboard = [
    {"name": "Zehrabs", "score": 320},
    {"name": "Gamze Taşkın", "score": 318},
    {"name": "Zeynep Serra", "score": 310},
    {"name": "Dilara İçöğlu", "score": 308},
    {"name": "Yusuf Emir", "score": 305},
    {"name": "Ahmet Yılmaz", "score": 290},
    {"name": "Furkan Mert", "score": 287},
  ];

  @override
  Widget build(BuildContext context) {
    // Kullanıcı sıralamasını belirlemek için örnek veri
    final String currentUser = "Yusuf Emir";
    final int currentUserRank =
        leaderboard.indexWhere((user) => user["name"] == currentUser) + 1;

    return Scaffold(
      appBar: AppBar(
        title: Text('Liderlik Sıralaması'),
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          children: [
            Text(
              'Liderlik Sıralaması',
              style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold),
            ),
            SizedBox(height: 10),
            Expanded(
              child: ListView.builder(
                itemCount: leaderboard.length,
                itemBuilder: (context, index) {
                  return ListTile(
                    leading: CircleAvatar(
                      child: Text('${index + 1}'),
                    ),
                    title: Text(leaderboard[index]['name'] as String),
                    trailing: Text('Skor: ${leaderboard[index]['score']}'),
                  );
                },
              ),
            ),
            SizedBox(height: 20),
            Text(
              'Mevcut Kullanıcı: $currentUser',
              style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
            ),
            Text(
              'Sıralamanız: $currentUserRank',
              style: TextStyle(fontSize: 18),
            ),
          ],
        ),
      ),
    );
  }
}
